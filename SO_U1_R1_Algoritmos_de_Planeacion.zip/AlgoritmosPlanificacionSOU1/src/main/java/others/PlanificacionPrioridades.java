/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package others;

import java.util.*;

class Proceso {
    int id;
    int tiempoLlegada;
    int tiempoRafaga;
    int prioridad;

    public Proceso(int id, int tiempoLlegada, int tiempoRafaga, int prioridad) {
        this.id = id;
        this.tiempoLlegada = tiempoLlegada;
        this.tiempoRafaga = tiempoRafaga;
        this.prioridad = prioridad;
    }
}

public class PlanificacionPrioridades {
    public static void ejecutar() {
        Proceso[] procesos = {
            new Proceso(1, 0, 6, 2),
            new Proceso(2, 2, 4, 1),
            new Proceso(3, 4, 3, 3),
            new Proceso(4, 6, 5, 2)
        };

        int n = procesos.length;
        int[] tiemposEspera = new int[n];
        int[] tiemposRetorno = new int[n];
        int[] tiemposFinalizacion = new int[n];
        int[] tiemposInicio = new int[n];
        int[] tiemposRespuesta = new int[n];

        // Ordenar los procesos por prioridad y tiempo de llegada (sin desalojo)
        Arrays.sort(procesos, (p1, p2) -> {
            if (p1.prioridad == p2.prioridad) {
                return Integer.compare(p1.tiempoLlegada, p2.tiempoLlegada);
            } else {
                return Integer.compare(p1.prioridad, p2.prioridad);
            }
        });

        // Calcular los tiempos de espera, retorno, finalización, inicio y respuesta
        int tiempoTotal = 0;
        for (int i = 0; i < n; i++) {
            Proceso proceso = procesos[i];
            if (proceso.tiempoLlegada > tiempoTotal) {
                tiempoTotal = proceso.tiempoLlegada;
            }
            tiemposInicio[proceso.id - 1] = tiempoTotal;
            tiemposEspera[proceso.id - 1] = tiempoTotal - proceso.tiempoLlegada;
            tiempoTotal += proceso.tiempoRafaga;
            tiemposFinalizacion[proceso.id - 1] = tiempoTotal;
            tiemposRetorno[proceso.id - 1] = tiempoTotal - proceso.tiempoLlegada;
            tiemposRespuesta[proceso.id - 1] = tiemposEspera[proceso.id - 1] + proceso.tiempoRafaga;
        }

        // Calcular los tiempos promedio
        double tiempoEsperaPromedio = calculateAverage(tiemposEspera);
        double tiempoRespuestaPromedio = calculateAverage(tiemposRespuesta);

        // Mostrar los resultados
        System.out.println("Proceso\t\tLlegada\t\tRáfaga\t\tPrioridad\tEspera\t\tRetorno\t\tFinalización\tRespuesta");
        for (int i = 0; i < n; i++) {
            Proceso proceso = procesos[i];
            System.out.printf("P%d\t\t%d\t\t%d\t\t%d\t\t%d\t\t%d\t\t%d\t\t%d\n",
                    proceso.id, proceso.tiempoLlegada, proceso.tiempoRafaga, proceso.prioridad,
                    tiemposEspera[proceso.id - 1], tiemposRetorno[proceso.id - 1],
                    tiemposFinalizacion[proceso.id - 1], tiemposRespuesta[proceso.id - 1]);
        }

        System.out.println("\nDiagrama de Gantt:");
        for (int i = 0; i < n; i++) {
            System.out.print("| P" + procesos[i].id + " ");
        }
        System.out.println("|");
        for (int i = 0; i < n; i++) {
            System.out.print(tiemposInicio[procesos[i].id - 1] + "\t");
        }
        System.out.println(tiemposFinalizacion[n - 1]);

        System.out.println("\nTiempo promedio de espera: " + tiempoEsperaPromedio);
        System.out.println("Tiempo promedio de respuesta: " + tiempoRespuestaPromedio);
    }

    private static double calculateAverage(int[] array) {
        int sum = 0;
        for (int value : array) {
            sum += value;
        }
        return (double) sum / array.length;
    }
}
