/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package sou1.so_u1_r2_atencionclientes;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

class Cliente {
    private String nombre;
    private int tipoCliente;
    private int tiempoAtencion;

    public Cliente(String nombre, int tipoCliente) {
        this.nombre = nombre;
        this.tipoCliente = tipoCliente;
        this.tiempoAtencion = generarTiempoAtencion();
    }

    public String getNombre() {
        return nombre;
    }

    public int getTipoCliente() {
        return tipoCliente;
    }

    public int getTiempoAtencion() {
        return tiempoAtencion;
    }

    private int generarTiempoAtencion() {
        Random random = new Random();
        return random.nextInt(10) + 1; // Genera un tiempo de atención aleatorio entre 1 y 10 segundos
    }
}

class Ventanilla {
    private String nombre;
    private Cliente clienteActual;
    private int tiempoRestante;

    public Ventanilla(String nombre) {
        this.nombre = nombre;
        this.clienteActual = null;
        this.tiempoRestante = 0;
    }

    public String getNombre() {
        return nombre;
    }

    public Cliente getClienteActual() {
        return clienteActual;
    }

    public int getTiempoRestante() {
        return tiempoRestante;
    }

    public void asignarCliente(Cliente cliente) {
        this.clienteActual = cliente;
        this.tiempoRestante = cliente.getTiempoAtencion();
        System.out.println("[" + this.nombre + "] Atendiendo al cliente: " + cliente.getNombre());
    }

    public void atenderCliente() {
        if (clienteActual != null) {
            tiempoRestante--;

            if (tiempoRestante <= 0) {
                System.out.println("[" + this.nombre + "] Cliente " + clienteActual.getNombre() + " atendido.");
                clienteActual = null;
                tiempoRestante = 0;
            }
        }
    }
}

public class AtencionClientes {
    public void ejecutar() {
        List<Cliente> clientes = new ArrayList<>();
        clientes.add(new Cliente("Cliente 1", 1));  // Cliente preferencial mayor de 60 años
        clientes.add(new Cliente("Cliente 2", 3));  // Cliente preferencial con necesidades especiales
        clientes.add(new Cliente("Cliente 3", 4));  // Cliente sin tarjeta
        clientes.add(new Cliente("Cliente 4", 2));  // Cliente preferencial con deficiencia física
        clientes.add(new Cliente("Cliente 5", 5));  // Cliente con tarjeta, cuenta común
        clientes.add(new Cliente("Cliente 6", 7));  // Cliente con tarjeta, persona jurídica común
        clientes.add(new Cliente("Cliente 7", 6));  // Cliente con tarjeta, persona natural VIP
        clientes.add(new Cliente("Cliente 8", 8));  // Cliente con tarjeta, persona jurídica VIP

        List<Ventanilla> ventanillas = new ArrayList<>();
        ventanillas.add(new Ventanilla("Ventanilla 1"));
        ventanillas.add(new Ventanilla("Ventanilla 2"));
        ventanillas.add(new Ventanilla("Ventanilla 3"));

        while (!clientes.isEmpty()) {
            int maxPriority = Integer.MIN_VALUE;
            Cliente nextCliente = null;

            for (Cliente cliente : clientes) {
                if (cliente.getTipoCliente() > maxPriority) {
                    maxPriority = cliente.getTipoCliente();
                    nextCliente = cliente;
                }
            }

            if (nextCliente != null) {
                Ventanilla ventanillaDisponible = null;

                for (Ventanilla ventanilla : ventanillas) {
                    if (ventanilla.getClienteActual() == null) {
                        ventanillaDisponible = ventanilla;
                        break;
                    }
                }

                if (ventanillaDisponible != null) {
                    ventanillaDisponible.asignarCliente(nextCliente);
                    clientes.remove(nextCliente);
                }
            }

            System.out.println("------------");
            System.out.println("Estado actual:");
            for (Ventanilla ventanilla : ventanillas) {
                System.out.println("[" + ventanilla.getNombre() + "] Cliente actual: " + (ventanilla.getClienteActual() != null ? ventanilla.getClienteActual().getNombre() : "Ninguno"));
            }
            System.out.println("------------");

            for (Ventanilla ventanilla : ventanillas) {
                ventanilla.atenderCliente();
            }

            try {
                Thread.sleep(1000); // Espera 1 segundo antes de la siguiente iteración para mayor claridad en la ejecución
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }
}

/*
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

class Cliente {
    private String nombre;
    private int tipoCliente;
    private int tiempoAtencion;

    public Cliente(String nombre, int tipoCliente) {
        this.nombre = nombre;
        this.tipoCliente = tipoCliente;
        this.tiempoAtencion = generarTiempoAtencion();
    }

    public String getNombre() {
        return nombre;
    }

    public int getTipoCliente() {
        return tipoCliente;
    }

    public int getTiempoAtencion() {
        return tiempoAtencion;
    }

    private int generarTiempoAtencion() {
        Random random = new Random();
        return random.nextInt(10) + 1; // Genera un tiempo de atención aleatorio entre 1 y 10 segundos
    }
}

class Ventanilla {
    private String nombre;
    private Cliente clienteActual;
    private int tiempoRestante;

    public Ventanilla(String nombre) {
        this.nombre = nombre;
        this.clienteActual = null;
        this.tiempoRestante = 0;
    }

    public String getNombre() {
        return nombre;
    }

    public Cliente getClienteActual() {
        return clienteActual;
    }

    public int getTiempoRestante() {
        return tiempoRestante;
    }

    public void asignarCliente(Cliente cliente) {
        this.clienteActual = cliente;
        this.tiempoRestante = cliente.getTiempoAtencion();
        System.out.println("[" + this.nombre + "] Atendiendo al cliente: " + cliente.getNombre());
    }

    public void atenderCliente() {
        if (clienteActual != null) {
            tiempoRestante--;

            if (tiempoRestante <= 0) {
                System.out.println("[" + this.nombre + "] Cliente " + clienteActual.getNombre() + " atendido.");
                clienteActual = null;
                tiempoRestante = 0;
            }
        }
    }
}

public class AtencionClientes {
    public void ejecutar(){
        List<Cliente> clientes = new ArrayList<>();
        clientes.add(new Cliente("Cliente 1", 1));  // Cliente preferencial mayor de 60 años
        clientes.add(new Cliente("Cliente 2", 3));  // Cliente preferencial con necesidades especiales
        clientes.add(new Cliente("Cliente 3", 4));  // Cliente sin tarjeta
        clientes.add(new Cliente("Cliente 4", 2));  // Cliente preferencial con deficiencia física
        clientes.add(new Cliente("Cliente 5", 5));  // Cliente con tarjeta, cuenta común
        clientes.add(new Cliente("Cliente 6", 7));  // Cliente con tarjeta, persona jurídica común
        clientes.add(new Cliente("Cliente 7", 6));  // Cliente con tarjeta, persona natural VIP
        clientes.add(new Cliente("Cliente 8", 8));  // Cliente con tarjeta, persona jurídica VIP

        List<Ventanilla> ventanillas = new ArrayList<>();
        ventanillas.add(new Ventanilla("Ventanilla 1"));
        ventanillas.add(new Ventanilla("Ventanilla 2"));
        ventanillas.add(new Ventanilla("Ventanilla 3"));

        while (!clientes.isEmpty()) {
            int maxPriority = Integer.MIN_VALUE;
            Cliente nextCliente = null;

            for (Cliente cliente : clientes) {
                if (cliente.getTipoCliente() > maxPriority) {
                    maxPriority = cliente.getTipoCliente();
                    nextCliente = cliente;
                }
            }

            if (nextCliente != null) {
                Ventanilla ventanillaDisponible = null;

                for (Ventanilla ventanilla : ventanillas) {
                    if (ventanilla.getClienteActual() == null) {
                        ventanillaDisponible = ventanilla;
                        break;
                    }
                }

                if (ventanillaDisponible != null) {
                    ventanillaDisponible.asignarCliente(nextCliente);
                    clientes.remove(nextCliente);
                }
            }

            for (Ventanilla ventanilla : ventanillas) {
                ventanilla.atenderCliente();
            }
        }
    }
}
*/