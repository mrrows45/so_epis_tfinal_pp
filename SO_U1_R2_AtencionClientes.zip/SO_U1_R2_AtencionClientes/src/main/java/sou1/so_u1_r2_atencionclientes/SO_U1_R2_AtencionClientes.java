/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Project/Maven2/JavaApp/src/main/java/${packagePath}/${mainClassName}.java to edit this template
 */
package sou1.so_u1_r2_atencionclientes;
//import sou1.so_u1_r2_atencionclientes.AtencionClientes;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

/**
 *
 * @author will_
 */
public class SO_U1_R2_AtencionClientes {

    public static void main(String[] args) {
        AtencionClientes a = new AtencionClientes();
        a.ejecutar();
    }
}

